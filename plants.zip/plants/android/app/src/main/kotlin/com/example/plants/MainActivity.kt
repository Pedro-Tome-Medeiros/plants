package com.example.plants

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
